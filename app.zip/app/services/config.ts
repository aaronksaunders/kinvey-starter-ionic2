export let KINVEY_BASE_URL = "https://baas.kinvey.com/";
let appKey = "kid1781"
let secretKey = "cb8b0da543e248e5a5ec9ab265cff1f2"
export let KINVEY_AUTH = btoa(appKey + ':' + secretKey)
