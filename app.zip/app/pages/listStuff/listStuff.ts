import {Page, NavController, NavParams, IonicApp} from 'ionic-framework/ionic';
import {ToDoService} from '../../services/todoService';
import {Authentication} from '../../services/authentication';
import {LoginPage} from '../../pages/user/login';

@Page({
  templateUrl: 'build/pages/listStuff/listStuff.html',
  providers: [ToDoService],
  //directives: [NgFor],
})

export class ListStuffPage {
  nav
  itemList

  constructor(app: IonicApp, nav: NavController, navParams: NavParams,
    public auth: Authentication,
    public tdService: ToDoService) {
    this.nav = nav;

    this.loadData()
  }

  loadData() {
    this.tdService.getAllItems().subscribe(
      (data) => {
        console.log('getAllItems', data)
        this.itemList = data
      },
      (err) => console.log("Error Retrieving Data:", JSON.parse(err._body).description),
      () => { console.log("All Good With The Data") }
      );
  }

  doLogout() {
    this.auth.logout().subscribe(
      (data) => {
        console.log('logging out', data)
        this.nav.setRoot(LoginPage, {});
      },
      (err) => console.log("Error Logging Out:", JSON.parse(err._body).description),
      () => { console.log("All Good With The Data") }
      );
  }
}
